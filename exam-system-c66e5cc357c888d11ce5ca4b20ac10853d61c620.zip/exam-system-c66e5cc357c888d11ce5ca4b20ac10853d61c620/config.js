  const BASE_URL = "https://exam-system-production.up.railway.app";

export default BASE_URL;
